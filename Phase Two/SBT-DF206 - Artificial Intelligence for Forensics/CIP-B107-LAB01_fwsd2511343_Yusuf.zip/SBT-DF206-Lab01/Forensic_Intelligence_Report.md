# FORENSIC INTELLIGENCE REPORT
## AI-Assisted IP Evidence Identification and Model Evaluation
**Case ID:** ICDFA-DFIR-AI-026  
**Student Name:** Almustapha Yusuf  
**Student ID:** fwsd2511343  
**Course:** AI for Forensics and Capstone Intelligence A (SBT-DF206/CIP-B107)  
**Date:** 18/11/2026  

---

### 1. Executive Forensic Intelligence Summary
This investigation evaluated the efficacy of AI-assisted triage for identifying genuine IPv4 evidence from mobile configuration strings. A fresh TF-IDF + Logistic Regression model achieved an **Accuracy of 82.61%** but exhibited a **high false positive rate (8 FP)** due to confusing invalid numerical patterns (e.g., `257.0.1.38`) for legitimate IPs. The historical fine-tuning logs (`result.csv`) lacked final evaluation metrics, rendering them unverifiable. **Recommendation:** Deploy the offline ML model only as an assistive triage tool, never as a sole decision-maker, due to its inability to distinguish between syntactically structured numbers and routable IPv4 addresses.

### 2. Evidence Preservation and Integrity (15 Marks)
All evidence was preserved in an untouched `originals/` folder. SHA-256 hashes were recorded in the evidence manifest.

| File | SHA-256 Hash | Size |
| :--- | :--- | :--- |
| `dataset_small.csv` | `74dbfbf...` | 16K |
| `dataset_train.jsonl` | `93938bd...` | 22K |
| `dataset_test.jsonl` | `77cc78e...` | 4.5K |
| `result.csv` | `42985fb...` | 41K |
| `fine_tuning_steps.txt` | `0633c41...` | 32K |

### 3. Dataset Profiling
*   **`dataset_small.csv`:** 229 records; columns `ip`, `class`, `text`. 77 duplicated rows. 
*   **`dataset_train.jsonl`:** 183 records (class balance: positive/negative).
*   **`dataset_test.jsonl`:** 46 records.

### 4. Candidate Extraction and Labelling (15 Marks)
A regex extractor was implemented, followed by a strict `ipaddress.IPv4Address` validator. The extractor identified 231 candidates. **Key Mismatch:** `1.000.000.000` was regex-matched but failed strict validation (octets > 255).

| Row | Candidate | Regex Match | IPv4 Valid | Source Label | Note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| 0 | `1.000.000.000` | True | False | A | Invalid octet (000) |
| 1 | `1.0.0.1` | True | True | A | Valid IPv4 |
| 3 | `1.1.1.1` | True | True | A | Valid IPv4 |
| 5 | `80.24.1.8` | True | True | A | Valid IPv4 |
| 12 | `192.95.36.142` | True | True | A | Valid IPv4 |

*(See `candidate_review.csv` for all 231 rows).*

### 5. Offline Model Evaluation (20 Marks)
*   **Model:** TF-IDF (character n-grams) + Logistic Regression
*   **Accuracy:** 82.61%
*   **Confusion Matrix:** `[[4, 8], [0, 34]]`
*   **Precision (Positive):** 0.81
*   **Recall (Positive):** 1.00
*   **F1-Score (Positive):** 0.89

### 6. Historical Fine-Tuning Analysis (15 Marks)
The provided `result.csv` showed `NaN` for all classification metrics (accuracy, precision, recall) at steps 1-5. The `fine_tuning_steps.txt` showed training loss dropping from `0.34` to `0.03`, indicating the historical model **overfit the training data** but did not provide verifiable holdout evaluation. Therefore, the historical metrics cannot be used as a reliable baseline.

### 7. Analyst Review of Errors (20 Marks)
*   **False Positives (8):** The model incorrectly flagged invalid IPs like `257.0.1.38`, `256.0.1.26`, and `0.0.0.0`. These are **numerical patterns** that the model memorized as IP-like, but the source label correctly marked as negative because they are either invalid (octets > 255) or non-routable.
*   **False Negatives (0):** The model successfully identified all true positives, indicating high recall (sensitivity) for genuine evidence.

### 8. Limitations and Recommendations
*   **False Positives:** In a real investigation, the 8 false positives would require manual analyst review, wasting approximately **17% of triage time** (8 out of 46 records).
*   **Historical Unreliability:** The historical fine-tuning job cannot be trusted due to missing metrics and likely overfitting.
*   **Deployment:** The model should be used as a *triage filter* to highlight potential IPs, but a strict `ipaddress` validator must be applied **after** the model to remove invalid addresses like `257.0.1.38` before presenting them to the analyst.

### 9. Deliverables Checklist
*   [x] Report (this document)
*   [x] Reproducible scripts (`phase_b`, `phase_c`, `phase_d`, `phase_e`)
*   [x] Evidence manifest (`evidence_manifest.csv`)
*   [x] Candidate review (`candidate_review.csv`)
*   [x] Predictions (`predictions.csv`)
*   [x] Confusion matrix (see `reports/phase_c_output.txt`)
*   [x] Screenshots (`screenshots/` folder)
