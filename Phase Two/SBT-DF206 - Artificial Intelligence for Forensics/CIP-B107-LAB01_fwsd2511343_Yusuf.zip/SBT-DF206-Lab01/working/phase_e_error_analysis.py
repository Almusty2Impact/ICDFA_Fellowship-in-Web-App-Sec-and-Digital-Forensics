import pandas as pd
import os

export_path = os.path.expanduser("~/SBT-DF206-Lab01/exported/")

print("=== Phase E: Error Analysis ===\n")

# Load predictions
df = pd.read_csv(os.path.join(export_path, 'predictions.csv'))

# 1. Separate TP, TN, FP, FN
# Positive class = 'positive'
TP = df[(df['actual'] == 'positive') & (df['predicted'] == 'positive')]
TN = df[(df['actual'] == 'negative') & (df['predicted'] == 'negative')]
FP = df[(df['actual'] == 'negative') & (df['predicted'] == 'positive')]
FN = df[(df['actual'] == 'positive') & (df['predicted'] == 'negative')]

print(f"True Positives (TP): {len(TP)}")
print(f"True Negatives (TN): {len(TN)}")
print(f"False Positives (FP): {len(FP)}")
print(f"False Negatives (FN): {len(FN)}\n")

# 2. Show the False Positives (Model said Positive, but was actually Negative)
print("--- False Positives (Investigate for Analyst Review) ---")
if len(FP) > 0:
    for idx, row in FP.iterrows():
        print(f"Record {idx}: Text='{row['text']}' | Actual='{row['actual']}' | Predicted='{row['predicted']}'")
else:
    print("No False Positives found.")

print("\n")

# 3. Show the False Negatives (Model said Negative, but was actually Positive)
print("--- False Negatives (Missed Evidence) ---")
if len(FN) > 0:
    for idx, row in FN.iterrows():
        print(f"Record {idx}: Text='{row['text']}' | Actual='{row['actual']}' | Predicted='{row['predicted']}'")
else:
    print("No False Negatives found.")

# 4. Save the errors to a CSV for the appendix
df_errors = pd.concat([FP, FN])
df_errors.to_csv(os.path.join(export_path, 'errors_review.csv'), index=False)
print(f"\nErrors saved to {export_path}/errors_review.csv")
