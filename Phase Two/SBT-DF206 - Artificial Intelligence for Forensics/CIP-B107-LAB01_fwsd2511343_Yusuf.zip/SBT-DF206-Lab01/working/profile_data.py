import pandas as pd
import json
import os

# Define the base path using the user's home directory to avoid path issues
base_path = os.path.expanduser("~/SBT-DF206-Lab01/originals/")

print("=== Phase A: Data Profiling ===\n")

# 1. Profile dataset_small.csv
print("--- dataset_small.csv ---")
csv_path = os.path.join(base_path, "dataset_small.csv")
df_small = pd.read_csv(csv_path)
print(f"Record count: {len(df_small)}")
print(f"Columns: {list(df_small.columns)}")
print(f"Null counts:\n{df_small.isnull().sum()}")
print(f"Duplicated rows: {df_small.duplicated().sum()}")
print("\nFirst 5 records:")
print(df_small.head())
print("\n")

# 2. Profile JSONL files
def profile_jsonl(filename):
    filepath = os.path.join(base_path, filename)
    print(f"--- {filename} ---")
    records = []
    with open(filepath, 'r') as f:
        for line in f:
            records.append(json.loads(line))
    print(f"Record count: {len(records)}")
    print(f"First record example:\n{records[0]}")
    print("\n")

profile_jsonl('dataset_train.jsonl')
profile_jsonl('dataset_test.jsonl')
