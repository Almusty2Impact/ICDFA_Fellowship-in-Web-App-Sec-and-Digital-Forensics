import pandas as pd
import json
import os
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
import joblib

base_path = os.path.expanduser("~/SBT-DF206-Lab01/originals/")
export_path = os.path.expanduser("~/SBT-DF206-Lab01/exported/")

# 1. Load JSONL data
def load_jsonl(filepath):
    data = []
    with open(filepath, 'r') as f:
        for line in f:
            record = json.loads(line)
            # Combine prompt and completion for the model text
            text = record['prompt']
            # Clean the label (removing space if present)
            label = record['completion'].strip()
            data.append((text, label))
    return data

print("Loading data...")
train_data = load_jsonl(os.path.join(base_path, 'dataset_train.jsonl'))
test_data = load_jsonl(os.path.join(base_path, 'dataset_test.jsonl'))

X_train = [x[0] for x in train_data]
y_train = [x[1] for x in train_data]

X_test = [x[0] for x in test_data]
y_test = [x[1] for x in test_data]

print(f"Training records: {len(X_train)}")
print(f"Testing records: {len(X_test)}")
print(f"Train labels: {set(y_train)}")
print(f"Test labels: {set(y_test)}\n")

# 2. TF-IDF Vectorization
# We use word-level and character-level n-grams to capture IP patterns
vectorizer = TfidfVectorizer(analyzer='char_wb', ngram_range=(2, 5), max_features=1000)
X_train_vec = vectorizer.fit_transform(X_train)
X_test_vec = vectorizer.transform(X_test)

# 3. Logistic Regression Model
model = LogisticRegression(random_state=42)
model.fit(X_train_vec, y_train)

# 4. Predictions
y_pred = model.predict(X_test_vec)

# 5. Evaluation
print("=== Model Evaluation ===")
print(f"Accuracy: {accuracy_score(y_test, y_pred):.4f}")
print("\nConfusion Matrix:")
print(confusion_matrix(y_test, y_pred))
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

# 6. Save the model and vectorizer for reproducibility
joblib.dump(model, os.path.join(export_path, 'logistic_model.pkl'))
joblib.dump(vectorizer, os.path.join(export_path, 'tfidf_vectorizer.pkl'))

# Save predictions to CSV
pred_df = pd.DataFrame({'text': X_test, 'actual': y_test, 'predicted': y_pred})
pred_df.to_csv(os.path.join(export_path, 'predictions.csv'), index=False)
print(f"\nPredictions saved to {export_path}/predictions.csv")
