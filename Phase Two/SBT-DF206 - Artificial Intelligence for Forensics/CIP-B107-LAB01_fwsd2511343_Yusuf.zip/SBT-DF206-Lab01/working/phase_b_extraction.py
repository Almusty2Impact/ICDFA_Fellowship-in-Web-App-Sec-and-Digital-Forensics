import pandas as pd
import re
import ipaddress
import os

# Define paths
base_path = os.path.expanduser("~/SBT-DF206-Lab01/originals/")
output_path = os.path.expanduser("~/SBT-DF206-Lab01/exported/")

# 1. Define Regex for IP-like patterns
# This matches strings that look like IPs (4 groups of digits separated by dots)
ip_regex = re.compile(r'\b(?:\d{1,3}\.){3}\d{1,3}\b')

# 2. Define Strict IPv4 Validator
def is_valid_ipv4(ip_string):
    try:
        ipaddress.IPv4Address(ip_string)
        return True
    except ipaddress.AddressValueError:
        return False

# 3. Load dataset_small.csv
df = pd.read_csv(os.path.join(base_path, 'dataset_small.csv'))

# 4. Process each record
results = []

for index, row in df.iterrows():
    source_text = row['text']
    source_label = row['class'] # 'A' might mean Anomaly/Actual, we'll see
    
    # Find all regex matches in the text
    matches = ip_regex.findall(source_text)
    
    if not matches:
        # If no IP found, record it
        results.append({
            'source_row': index,
            'context': source_text,
            'candidate': 'NONE_FOUND',
            'regex_match': False,
            'ipv4_valid': False,
            'source_label': source_label,
            'analyst_note': 'No IP pattern found in text.'
        })
    else:
        for match in matches:
            regex_hit = True
            valid_hit = is_valid_ipv4(match)
            
            # Determine the note based on discrepancies
            note = ""
            if valid_hit:
                note = "Valid IPv4 address."
            else:
                note = "Regex matched, but strict IPv4 validation failed (e.g., octet > 255 or leading zeros)."
                
            results.append({
                'source_row': index,
                'context': source_text,
                'candidate': match,
                'regex_match': regex_hit,
                'ipv4_valid': valid_hit,
                'source_label': source_label,
                'analyst_note': note
            })

# Convert to DataFrame
df_review = pd.DataFrame(results)

# Save to CSV
output_file = os.path.join(output_path, 'candidate_review.csv')
df_review.to_csv(output_file, index=False)
print(f"Extraction complete. {len(df_review)} candidates processed.")
print(f"Saved to {output_file}")

# 5. Generate the 10 required samples for the report
print("\n=== 10 Sample Candidates for Report ===")
# We will just print the first 10 unique candidates to show the logic
sample_df = df_review.drop_duplicates(subset=['candidate']).head(10)
for idx, row in sample_df.iterrows():
    print(f"Row {row['source_row']}: Candidate={row['candidate']}, Regex={row['regex_match']}, Valid={row['ipv4_valid']}, Note={row['analyst_note']}")
