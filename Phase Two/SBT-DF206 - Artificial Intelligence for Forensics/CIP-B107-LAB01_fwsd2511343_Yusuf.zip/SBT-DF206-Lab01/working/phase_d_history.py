import pandas as pd
import os

base_path = os.path.expanduser("~/SBT-DF206-Lab01/originals/")
report_path = os.path.expanduser("~/SBT-DF206-Lab01/reports/")

print("=== Phase D: Historical Fine-Tuning Evidence ===\n")

# 1. Read fine_tuning_steps.txt (Historical Training Log)
print("--- Fine-Tuning Steps (First 10 lines) ---")
steps_file = os.path.join(base_path, 'fine_tuning_steps.txt')
with open(steps_file, 'r') as f:
    lines = f.readlines()
    # Print the first 10 lines to see the structure
    for line in lines[:10]:
        print(line.strip())
print("\n")

# 2. Read result.csv (Historical Evaluation Metrics)
print("--- Historical Model Results (result.csv) ---")
result_file = os.path.join(base_path, 'result.csv')
try:
    df_results = pd.read_csv(result_file)
    print(f"Columns: {list(df_results.columns)}")
    print("First few records:")
    print(df_results.head())
except Exception as e:
    print(f"Error reading result.csv: {e}")

# 3. Create a comparison table
# Note: We will manually fill in our Phase C metrics for comparison
print("\n=== Comparison: Historical vs. Our Model ===")
comparison_data = {
    'Model': ['Historical Fine-Tuned Model (result.csv)', 'Our Fresh TF-IDF + Logistic Regression'],
    'Accuracy': ['TBD from result.csv', '0.8261'],
    'Precision (Positive)': ['TBD', '0.81'],
    'Recall (Positive)': ['TBD', '1.00'],
    'F1-Score (Positive)': ['TBD', '0.89']
}
df_compare = pd.DataFrame(comparison_data)
print(df_compare.to_string(index=False))
