# CIP-B107 Lab Submission
**Student:** Almustapha Yusuf (fwsd2511343)
**Course:** AI for Forensics and Capstone Intelligence A

## Contents:
- `Forensic_Intelligence_Report.md` (Main Report)
- `working/` (Python scripts for phases B, C, D, E)
- `evidence_manifest.csv` (Chain of custody)
- `exported/` (candidate_review.csv, predictions.csv, errors_review.csv)
- `reports/` (Text outputs for all phases)
- `screenshots/` (6+ screenshots of terminal outputs)

## Reproducibility:
Run the scripts in order:
1. `python3 working/profile_data.py`
2. `python3 working/phase_b_extraction.py`
3. `python3 working/phase_c_classifier.py`
4. `python3 working/phase_d_history.py`
5. `python3 working/phase_e_error_analysis.py`
